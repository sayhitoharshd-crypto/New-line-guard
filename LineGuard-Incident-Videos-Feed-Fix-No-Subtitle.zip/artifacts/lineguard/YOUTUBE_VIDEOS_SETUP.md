# Incident-related YouTube videos

LineGuard's main feed includes a standalone Incident videos section that searches YouTube independently of public case availability. Report cards show a related result per incident; the public case discussion screen can show up to three. Results show the video title, channel, an embedded player, and a link to the original YouTube page. The player requests muted autoplay and inline playback; device/browser autoplay policies can still require user interaction. Search results are not verification or evidence of the incident.

## Configure the YouTube API key

1. Create a YouTube Data API v3 key in Google Cloud Console and restrict it to the YouTube Data API v3. Because an `EXPO_PUBLIC_` value is embedded in the app, treat it as a public client key; apply API and application restrictions and quota limits. Do not use a privileged server key.
2. In GitHub, open **Settings → Secrets and variables → Actions → New repository secret** and create `YOUTUBE_API_KEY`.
3. The repository's APK workflow must expose that secret as `EXPO_PUBLIC_YOUTUBE_API_KEY` during the Expo/Gradle JavaScript bundle build. Never commit the key into source files.
4. Rebuild the APK. Without the key, related video sections remain hidden.

Search results are automatically chosen by YouTube for the report description and location. Moderators/users should review relevance before treating a result as related to a case. Videos are embedded from YouTube; LineGuard does not download or re-upload them.
