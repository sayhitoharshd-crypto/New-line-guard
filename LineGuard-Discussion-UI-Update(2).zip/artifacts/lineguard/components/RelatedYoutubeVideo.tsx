import React, { useEffect, useState } from "react";
import { ActivityIndicator, Linking, StyleSheet, Text, View } from "react-native";
import { WebView } from "react-native-webview";

type VideoResult = { id: string; title: string; channel: string };
const cache = new Map<string, VideoResult | null>();

export function RelatedYoutubeVideo({ query, visible = true }: { query: string; visible?: boolean }) {
  const [result, setResult] = useState<VideoResult | null | undefined>(undefined);
  const [failed, setFailed] = useState(false);
  const apiKey = process.env.EXPO_PUBLIC_YOUTUBE_API_KEY;
  const cleanQuery = query.trim().replace(/\s+/g, " ").slice(0, 180);

  useEffect(() => {
    let active = true;
    if (!visible || !cleanQuery || !apiKey) return () => { active = false; };
    const cached = cache.get(cleanQuery);
    if (cached !== undefined) { setResult(cached); return () => { active = false; }; }
    setResult(undefined);
    const search = async () => {
      try {
        const params = new URLSearchParams({ part: "snippet", type: "video", maxResults: "1", safeSearch: "strict", q: `${cleanQuery} incident news`, key: apiKey });
        const response = await fetch(`https://www.googleapis.com/youtube/v3/search?${params.toString()}`);
        if (!response.ok) throw new Error(`YouTube search failed (${response.status})`);
        const data = await response.json();
        const item = data.items?.[0];
        const found: VideoResult | null = item?.id?.videoId ? { id: item.id.videoId, title: item.snippet?.title || "Related video", channel: item.snippet?.channelTitle || "YouTube" } : null;
        cache.set(cleanQuery, found);
        if (active) setResult(found);
      } catch { if (active) { setResult(null); setFailed(true); } }
    };
    void search();
    return () => { active = false; };
  }, [apiKey, cleanQuery, visible]);

  if (!visible || !apiKey) return null;
  if (result === undefined) return <View style={styles.loading}><ActivityIndicator color="#7C3AED"/><Text style={styles.muted}>Finding a related video…</Text></View>;
  if (!result) return <Text style={styles.muted}>{failed ? "Related video unavailable" : "No related video found"}</Text>;

  const videoUrl = `https://www.youtube.com/watch?v=${result.id}`;
  const html = `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"/><style>html,body{margin:0;padding:0;background:#000;width:100%;height:100%;overflow:hidden}iframe{border:0;width:100%;height:100%}</style></head><body><iframe src="https://www.youtube-nocookie.com/embed/${result.id}?autoplay=1&mute=1&playsinline=1&controls=1&rel=0" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe></body></html>`;
  return <View style={styles.wrap}>
    <View style={styles.player}>
      <WebView
        source={{ html, baseUrl: "https://www.youtube-nocookie.com" }}
        javaScriptEnabled
        domStorageEnabled
        allowsInlineMediaPlayback
        mediaPlaybackRequiresUserAction={false}
        allowsFullscreenVideo
        originWhitelist={["https://*", "about:*"]}
        mixedContentMode="always"
        scrollEnabled={false}
        style={styles.webview}
      />
    </View>
    <Text style={styles.title} numberOfLines={2}>{result.title}</Text>
    <Text style={styles.channel}>{result.channel} · YouTube</Text>
    <Text accessibilityRole="link" onPress={() => { void Linking.openURL(videoUrl); }} style={styles.link}>Open original video on YouTube ↗</Text>
  </View>;
}

const styles = StyleSheet.create({
  wrap: { marginTop: 12, borderRadius: 12, overflow: "hidden", borderWidth: 1, borderColor: "#D1D5DB", backgroundColor: "#FFFFFF" },
  player: { width: "100%", aspectRatio: 16 / 9, backgroundColor: "#000" },
  webview: { flex: 1, backgroundColor: "#000" },
  loading: { minHeight: 48, flexDirection: "row", alignItems: "center", gap: 8, padding: 10 },
  muted: { color: "#6B7280", fontSize: 12, padding: 8 },
  title: { color: "#111827", fontSize: 13, fontWeight: "700", paddingHorizontal: 10, paddingTop: 8 },
  channel: { color: "#6B7280", fontSize: 11, paddingHorizontal: 10, paddingTop: 3 },
  link: { color: "#6D28D9", fontSize: 12, fontWeight: "600", padding: 10 },
});
