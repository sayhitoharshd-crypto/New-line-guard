import { Feather } from "@expo/vector-icons";
import React, { useEffect, useState } from "react";
import { ActivityIndicator, Linking, Pressable, StyleSheet, Text, View } from "react-native";
import { WebView } from "react-native-webview";
import { useColors } from "@/hooks/useColors";

type Video = { id: string; title: string; channel: string; url: string };
const API_KEY = process.env.EXPO_PUBLIC_YOUTUBE_API_KEY;
const INCIDENT_TOPICS = [
  "queue cutting public incident", "stampede crowd crush incident",
  "public fight altercation", "harassment in public place",
  "Delhi Metro incident", "Mumbai local train incident",
  "road rage incident", "overcrowding public transport",
  "public place theft incident", "crowd mismanagement public incident",
  "bus train passenger altercation", "public safety incident India",
];
let topicRotation = 0;
const TOPICS_PER_REFRESH = 4;
const RESULTS_PER_TOPIC = 3;
const MAX_FEED_VIDEOS = 10;

function embedHtml(videoId: string) {
  const src = `https://www.youtube-nocookie.com/embed/${encodeURIComponent(videoId)}?autoplay=1&mute=1&playsinline=1&controls=1&rel=0`;
  return `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"></head><body style="margin:0;background:#000"><iframe src="${src}" title="YouTube video" style="position:absolute;inset:0;width:100%;height:100%;border:0" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe></body></html>`;
}

export function IncidentVideos({ query, compact = false }: { query: string; compact?: boolean }) {
  const colors = useColors();
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  useEffect(() => {
    let active = true;
    if (!API_KEY || !query.trim()) return;

    const startAt = topicRotation % INCIDENT_TOPICS.length;
    topicRotation = (topicRotation + TOPICS_PER_REFRESH) % INCIDENT_TOPICS.length;
    const topics = Array.from({ length: TOPICS_PER_REFRESH }, (_, index) =>
      INCIDENT_TOPICS[(startAt + index) % INCIDENT_TOPICS.length]
    );

    setLoading(true);
    setError(false);
    const search = async () => {
      try {
        const responses = await Promise.allSettled(topics.map(async (topic) => {
          const params = new URLSearchParams({
            part: "snippet", type: "video",
            maxResults: String(compact ? 2 : RESULTS_PER_TOPIC),
            safeSearch: "strict", q: `${query} ${topic} news`, key: API_KEY,
          });
          const response = await fetch(`https://www.googleapis.com/youtube/v3/search?${params.toString()}`);
          if (!response.ok) throw new Error("YouTube search failed");
          const data = await response.json();
          return (data.items ?? []).map((item: any) => ({
            id: item.id?.videoId,
            title: item.snippet?.title ?? "Related video",
            channel: item.snippet?.channelTitle ?? "YouTube",
            url: `https://www.youtube.com/watch?v=${item.id?.videoId}`,
          })).filter((video: Video) => !!video.id) as Video[];
        }));

        const merged: Video[] = [];
        const seenIds = new Set<string>();
        let successfulSearches = 0;
        for (const response of responses) {
          if (response.status !== "fulfilled") continue;
          successfulSearches += 1;
          for (const video of response.value) {
            if (seenIds.has(video.id)) continue;
            seenIds.add(video.id);
            merged.push(video);
            if (merged.length >= MAX_FEED_VIDEOS) break;
          }
          if (merged.length >= MAX_FEED_VIDEOS) break;
        }
        if (active) {
          setVideos(merged);
          setError(successfulSearches === 0);
        }
      } catch {
        if (active) setError(true);
      } finally {
        if (active) setLoading(false);
      }
    };
    void search();
    return () => { active = false; };
  }, [query, compact]);

  if (!API_KEY) return <Text style={[styles.notice, { color: colors.mutedForeground }]}>Videos unavailable: YouTube API key is not configured in this build.</Text>;
  if (loading && videos.length === 0) return <View style={styles.loading}><ActivityIndicator color={colors.primary} /><Text style={{ color: colors.mutedForeground }}>Finding related videos…</Text></View>;
  if (error) return <Text style={[styles.notice, { color: colors.mutedForeground }]}>Could not load YouTube videos. Check the API key and connection.</Text>;
  if (videos.length === 0) return <Text style={[styles.notice, { color: colors.mutedForeground }]}>No matching YouTube videos found.</Text>;

  return <View style={styles.section}>
    <Text style={[styles.heading, { color: colors.foreground }]}>Related videos</Text>
    {videos.map(video => <View key={video.id} style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.player, compact && styles.compactPlayer]}>
        <WebView source={{ html: embedHtml(video.id), baseUrl: "https://www.youtube-nocookie.com" }} originWhitelist={["https://*", "http://*"]} javaScriptEnabled domStorageEnabled allowsInlineMediaPlayback mediaPlaybackRequiresUserAction={false} allowsFullscreenVideo setSupportMultipleWindows={false} />
      </View>
      <View style={styles.meta}>
        <Text style={[styles.videoTitle, { color: colors.foreground }]} numberOfLines={2}>{video.title}</Text>
        <Text style={[styles.channel, { color: colors.mutedForeground }]}>{video.channel} · YouTube</Text>
        <Pressable onPress={() => { void Linking.openURL(video.url); }} accessibilityRole="link" style={styles.sourceLink}>
          <Feather name="external-link" size={13} color={colors.primary} /><Text style={{ color: colors.primary, fontSize: 12, fontWeight: "700" }}>Open source video</Text>
        </Pressable>
      </View>
    </View>)}
    <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>Videos are surfaced by YouTube search and may not verify the incident. Review before relying on them.</Text>
  </View>;
}

const styles = StyleSheet.create({
  section: { paddingHorizontal: 16, paddingTop: 12, gap: 10 }, notice: { paddingHorizontal: 16, paddingVertical: 10, fontSize: 12 }, heading: { fontSize: 16, fontWeight: "800" }, card: { borderWidth: 1, borderRadius: 14, overflow: "hidden" }, player: { width: "100%", height: 220, backgroundColor: "#000" }, compactPlayer: { height: 190 }, meta: { padding: 12, gap: 5 }, videoTitle: { fontSize: 14, fontWeight: "700" }, channel: { fontSize: 11 }, sourceLink: { flexDirection: "row", alignItems: "center", gap: 5, alignSelf: "flex-start", paddingTop: 3 }, disclaimer: { fontSize: 10, lineHeight: 14 }, loading: { padding: 16, flexDirection: "row", gap: 8, alignItems: "center" },
});
